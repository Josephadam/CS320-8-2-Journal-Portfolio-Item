package com.mobileApplication.Mobile_Application.contactservice;


import java.util.HashMap;
import java.util.Map;

public class ContactService {
    // Stores contacts using their contactId as the key
    private final Map<String, Contact> contacts = new HashMap<>();

    // Adds a new contact if the ID doesn't already exist
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists.");
        }
        contacts.put(contact.getContactId(), contact);
    }

    // Deletes a contact by ID if it exists
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        contacts.remove(contactId);
    }

    // Updates the first name of an existing contact
    public void updateFirstName(String contactId, String firstName) {
        Contact contact = getContactById(contactId);
        contact.setFirstName(firstName);
    }

    // Updates the last name of an existing contact
    public void updateLastName(String contactId, String lastName) {
        Contact contact = getContactById(contactId);
        contact.setLastName(lastName);
    }

    // Updates the phone number of an existing contact
    public void updatePhone(String contactId, String phone) {
        Contact contact = getContactById(contactId);
        contact.setPhone(phone);
    }

    // Updates the address of an existing contact
    public void updateAddress(String contactId, String address) {
        Contact contact = getContactById(contactId);
        contact.setAddress(address);
    }

    // Retrieves a contact by ID or throws an exception if not found
    private Contact getContactById(String contactId) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        return contact;
    }
}
