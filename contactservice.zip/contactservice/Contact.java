package com.mobileApplication.Mobile_Application.contactservice;


public class Contact {
    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;
    
    
    // Constructor for the Contact class
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
    	
    	// Validate contact ID: not null and max 10 characters
        if (contactId == null || contactId.length() > 10)
            throw new IllegalArgumentException("Invalid contact ID");
        // Validate first name: not null and max 10 characters
        if (firstName == null || firstName.length() > 10)
            throw new IllegalArgumentException("Invalid first name");
        // Validate last name: not null and max 10 characters
        if (lastName == null || lastName.length() > 10)
            throw new IllegalArgumentException("Invalid last name");
        // Validate phone number: not null and must equal 10 characters
        if (phone == null || phone.length() != 10)
            throw new IllegalArgumentException("Invalid phone number");
        // Validate address: not null and max 30 characters
        if (address == null || address.length() > 30)
            throw new IllegalArgumentException("Invalid address");
        // Assign values to the fields
        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }
    
    // setter for first name
    public void setFirstName(String firstName) {
    	// checks First name and check is not null and greater than 10 char
        if (firstName == null || firstName.length() > 10)
            throw new IllegalArgumentException("Invalid first name");
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }
    
    // setter for last name
    public void setLastName(String lastName) {
    	// checks Last name and check is not null and greater than 10 char
        if (lastName == null || lastName.length() > 10)
            throw new IllegalArgumentException("Invalid last name");
        this.lastName = lastName;
    }

    public String getPhone() {
        return phone;
    }

    // setter for last name
    public void setPhone(String phone) {
    	// checks phone and check is not null and equal 10 char
        if (phone == null || phone.length() != 10)
            throw new IllegalArgumentException("Invalid phone number");
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }
    // setter for last name
    public void setAddress(String address) {
    	// checks address and check is not null and greater than 30
        if (address == null || address.length() > 30)
            throw new IllegalArgumentException("Invalid address");
        this.address = address;
    }
}
