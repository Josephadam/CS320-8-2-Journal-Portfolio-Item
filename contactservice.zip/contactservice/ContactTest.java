package com.mobileApplication.Mobile_Application.contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

	// Test valid contact creation
    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("001", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    // Test valid contact id too long
    @Test
    public void testInvalidContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St");
        });
    }
    // Test null first name
    @Test
    public void testNullFirstName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("002", null, "Doe", "1234567890", "123 Main St");
        });
    }
    // Test null last name
    @Test
    public void testPhoneNotTenDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("003", "John", "Doe", "12345", "123 Main St");
        });
    }
    // Test address too long
    @Test
    public void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("004", "John", "Doe", "1234567890", "1234567890123456789012345678901");
        });
    }
    
    // Test valid contact creation with maximum length fields
    @Test
    public void testNullContactId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Doe", "1234567890", "123 Main St");
        });
    }
    
    // Test valid first name
    @Test
    public void testNullLastName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("005", "John", null, "1234567890", "123 Main St");
        });
    }
    
    // Test valid phone number
    @Test
    public void testNullPhone() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("006", "John", "Doe", null, "123 Main St");
        });
    }
    
    // Test valid address
    @Test
    public void testNullAddress() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("007", "John", "Doe", "1234567890", null);
        });
    }
    
    // Test first name too long
    @Test
    public void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("008", "TooLongFirst", "Doe", "1234567890", "123 Main St");
        });
    }
    
    // Test last name too long
    @Test
    public void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("009", "John", "TooLongLast", "1234567890", "123 Main St");
        });
    }

    
    
    
}
